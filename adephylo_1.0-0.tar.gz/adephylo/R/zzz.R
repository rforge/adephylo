.First.lib <- function (lib, pkg){
  library.dynam("adephylo", pkg, lib)
}
